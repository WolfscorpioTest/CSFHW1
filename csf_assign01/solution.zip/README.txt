TODO: add information about contributions of team member(s)
Alexander Shen ashen12 wrote methods and testing
Bohan Hou helped with testing
