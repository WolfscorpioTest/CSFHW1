TODO: add information about contributions of team member(s)
Alexander Shen ashen12
Bohan Hou 
